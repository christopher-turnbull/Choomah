# Python choomah-exception



The Python `choomah-exception` library is a developer kit for integrating with the PIP69240 comprehensive list of standards.

Comprehensive code and documentation is left as an exercise to the reader.

The **Python choomah-expection** allows:

- The playing of the said 'choomah scream' everytime an exception is captured (similar to oooOOOOAAAAAAAAAAA)
- Overwriting other exceptions in progress

Future versions are working on controlling system volume


### Requirements

We make use of PyAudio http://people.csail.mit.edu/hubert/pyaudio/

`$ pip install pyaudio`

If you run Mac OS X, be sure to first run


`$ pip brew install portaudio` 
